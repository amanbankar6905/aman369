import math

# Starting position
x, y = 0, 0

# Sequence of movements: direction steps
movements = [
    ("UP", 5),
    ("DOWN", 3),
    ("LEFT", 3),
    ("RIGHT", 2)
]

# Process each movement
for direction, steps in movements:
    if direction == "UP":
        y += steps
    elif direction == "DOWN":
        y -= steps
    elif direction == "LEFT":
        x -= steps
    elif direction == "RIGHT":
        x += steps
    
    print(f"{direction} {steps}: Current position ({x}, {y})")

# Calculate distance from origin using math module
distance = math.sqrt(x**2 + y**2)

print(f"\nFinal position: ({x}, {y})")
print(f"Distance from origin: {distance:.2f}")
